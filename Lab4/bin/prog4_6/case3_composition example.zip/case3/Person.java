package prog4_6.case3;

import java.util.GregorianCalendar;

import prog4_6.case2.PersonWithJob;

public class Person {

	private String name;
	private GregorianCalendar dateOfBirth;
	Person(String name, GregorianCalendar dob) {
		this.name = name;
		dateOfBirth = dob;
	}
	public String getName() {
		return name;
	}
	
	public GregorianCalendar getDateOfBirth() {
		return (GregorianCalendar)dateOfBirth.clone();
	}
	
	public boolean equals(Object ob) {
		if(ob == null) return false;
		if(!(ob instanceof Person)) return false;
		Person p = (Person)ob;
		return p.name.equals(name) && p.dateOfBirth.equals(dateOfBirth);
	}
	
	public int hashCode() {
		int seed = 17;
		int result = 31 * seed + name.hashCode();
		result = 31 * result + dateOfBirth.hashCode();
		return result;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonWithJob p=new PersonWithJob("Pukar Subedi",new GregorianCalendar(2009,12,12),5000);
		PersonWithJob p2=new PersonWithJob("Pukar Subedi",new GregorianCalendar(2000,12,12),5000);
		if(p.equals(p2))
		{
			System.out.println("They are the same person");
		}
		else
		{
			System.out.println("They are not the same person");
		}

	}

}
